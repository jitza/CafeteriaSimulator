/*  Done by: Farshad Rabbani
    Nov 22, 2004
    Purpose: Generate a file of students
*/
/*-------------------------------------------------*/
/*  Modified by: Jenny Itza
    April 14, 2023
*/

#include<iostream>
#include<fstream>
#include<string>
#include<stdlib.h>//for rand()
#include <time.h>
using namespace std;

void GenerateFile(fstream &, string*, const int,
                  string*, string*, string*);

void randomizeNames(string *, const int);

int main()
{

    int numRecords = 0;

    srand(time(NULL));

    cout<<"Please enter the number of student records you want in your file: ";
    cin>>numRecords;

    while( numRecords > 120 || numRecords < 1)
    {
        cout<<"You cannot create more than 120 records! "
            <<"\nThat exceeds the number of available trays\n";

        cout<<"Please enter the number of student records you want generated: ";
        cin>>numRecords;

    }


    string Schools[] = {"Eastville","Westburg","Northton","Southport","Jahunga","Podunk"};

    string Entrees[] = {"Chicken","Fishsticks","Lasagna"};

    string Desserts[] = {"Cheesecake","Pudding"};


    char InFile[] = "names.txt";
    char OutFile[] = "Students.txt";


    fstream Input(InFile, ios::in);
    fstream Output(OutFile, ios::out);

    string names[120];
    int i = 0;
    string s;

    if(Input)
    {
        while (!Input.eof())
            getline(Input, names[i++]); // Discards newline char


        randomizeNames(names, i);

        GenerateFile(Output, names, numRecords, Schools, Entrees, Desserts);

        Input.close();
        Output.close();

        cout << "The file " << OutFile << " was created for you.\n\n";
    }
    else
    cout<<"File name.txt was not found"<<endl;
}



void GenerateFile(fstream &Out, string* name, const int records,
                  string* School, string* Entree, string* Dessert )
{

    int seed = rand();

    Out<<seed<<endl;

    for(int i = 0; i < records; i++)
    {
        Out << name[i] << endl;
        Out << School[rand() % 6 ] << endl ;  //select a random school
        Out << (rand() % 10) << endl; //select a random number of ounces between 0-10
        Out << Entree[rand() % 3 ] << endl;   //select random entree
        Out << Dessert[rand() % 2 ] << endl;  //select random dessert
    }
    Out << "Done" << endl;
}


void randomizeNames( string * arrayOfNames, const int arraySize )
{
    string hold;
    int randomPosition;
    for ( int i = 0; i < arraySize; i++)
    {
        randomPosition = rand() % arraySize;
        hold = arrayOfNames[i];
        arrayOfNames[i] = arrayOfNames[randomPosition];
        arrayOfNames[randomPosition] = hold;

    }


}
